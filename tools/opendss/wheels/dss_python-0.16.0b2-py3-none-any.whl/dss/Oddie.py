from __future__ import annotations
import sys, platform, ctypes, os
from typing import Optional
from ._cffi_api_util import AltDSSAPIUtil
from .IDSS import IDSS
from enum import Flag

class OddieOptions(Flag):
    MapErrors = 0x01


class IOddieDSS(IDSS):
    r'''
    The OddieDSS class exposes the official OpenDSSDirect.DLL binary,
    as distributed by EPRI, with the same API as the DSS-Python and
    EPRI's OpenDSS COM interface object on Windows. It uses AltDSS Oddie
    to achieve this.

    **Note:** This class requires the backend for Oddie to be included in
    the `dss_python_backend` package. If it is not available, an import 
    error should occur when trying to use this.

    AltDSS Oddie wraps OpenDSSDirect.DLL, providing a minimal compatibility layer
    to expose it with the same API as AltDSS/DSS C-API. With it, we can
    just reuse most of the tools from the other projects on DSS-Extensions
    without too much extra work.

    Note that many functions from DSS-Extensions will not be available and/or
    will return errors, and this is expected. There are some issues and/or
    limitations from OpenDSSDirect.DLL that may or may not affect specific
    use cases; check the documentation on https://dss-extensions.org for 
    more information.

    :param library_path: The name or full path of the target dynamic library to
    load. Defaults to trying to load "OpenDSSDirect" from `C:\Program Files\OpenDSS\x64`,
    followed by trying to load it from the current path.

    :param load_flags: Optional, flags to feed the [`LoadLibrary`](https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-loadlibraryexa) 
    (on Windows) or `dlopen` (on Linux and macOS, whenever EPRI supports it). If not provided, a default set will be used.

    :param oddie_options: Optional, Oddie configuration flags. If none passed,
    the default settings (recommended) will be used. For advanced users.
    '''

    def _handle_load_lib_error(self):
        '''
        This function is used to try to provide a more helpful message when the
        library cannot be loaded.
        '''
        try:
            if sys.platform == 'win32':
                error = ctypes.GetLastError()
                if error:
                    raise ctypes.WinError(error)

                return

            if sys.platform == 'linux':
                # ld = ctypes.cdll.LoadLibrary("ld-linux-x86-64.so.2")
                # ld.dlerror.argtypes = []
                # ld.dlerror.restype = ctypes.c_char_p
                # error = ld.dlerror()
                # if error:
                #     raise RuntimeError(error.decode())
                return
        except:
            # We can ignore if something fails since the generic 
            # check will still work outside.
            pass


    def is_oddie(self) -> bool:
        """
        Returns True if this instance is based on the Oddie compatibility layer for
        EPRI's OpenDSS Direct API (a.k.a. DCSL).
        
        Note that the default instance in OpenDSSDirect.py is based on AltDSS since 2018.
        """
        return True

    def __init__(self, library_path: str = '', load_flags: Optional[int] = None, oddie_options: Optional[OddieOptions] = None):
        if sys.platform == 'cygwin':
            raise NotImplementedError("Cygwin support is not implemented")
        elif sys.platform == 'wasi':
            raise NotImplementedError("WASI support is not implemented")
        elif sys.platform == 'win32':
            not64bits = (platform.architecture()[0] != '64bit')
            if not64bits:
                raise NotImplementedError("On Windows, only 64-bit (x64) environments are supported with Oddie. If you need support for further architectures, please open an issue at https://github.com/dss-extensions/")

        from dss_python_backend import oddie as oddie_capi
        lib = oddie_capi.lib
        ffi = oddie_capi.ffi
        NULL = ffi.NULL
        
        c_load_flags = NULL
        if load_flags is not None:
            c_load_flags = ffi.new('uint32_t*', load_flags)

        if library_path:
            if not isinstance(library_path, bytes):
                library_path = str(library_path).encode()

            lib.Oddie_SetLibOptions(library_path, c_load_flags)
            ctx = lib.ctx_New()
            if ctx == NULL:
                self._handle_load_lib_error()

        elif sys.platform == 'win32':
            _win32_lib_paths = [
                rb'C:\Program Files\OpenDSS\x64\OpenDSSDirect.dll', # Try the default install folder
                rb'OpenDSSDirect.dll', # Try from the general path, let the system resolve it
            ]

            for library_path in _win32_lib_paths:
                lib.Oddie_SetLibOptions(library_path, c_load_flags)
                ctx = lib.ctx_New()
                if ctx != NULL:
                    break
            else:
                self._handle_load_lib_error()

        elif sys.platform == 'linux':
            library_path = b'libOpenDSSC.so' #TODO: add proper version extensions (e.g. libOpenDSSC.so.10)
            lib.Oddie_SetLibOptions(library_path, c_load_flags)
            ctx = lib.ctx_New()
            if ctx == NULL:
                self._handle_load_lib_error()

        if ctx == NULL:
            raise RuntimeError("Could not load the target library.")

        if lib.DSS_Start(ctx, 0) == 0:
            raise RuntimeError("DSS_Start call was not successful.")

        if oddie_options is not None:
            lib.Oddie_SetOptions(oddie_options)

        ctx = ffi.gc(ctx, lib.ctx_Dispose)
        api_util = AltDSSAPIUtil(ffi, lib, ctx, is_oddie=True)
        api_util._library_path = library_path
        IDSS.__init__(self, api_util)


__all__ = ['IOddieDSS', 'OddieOptions']